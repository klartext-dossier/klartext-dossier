class TaskException(Exception):

    """ Task exception.

        Indicates any failure of a task.
    """

    pass
